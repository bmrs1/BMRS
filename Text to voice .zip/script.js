document.getElementById('convert-button').addEventListener('click', function() {
    const text = document.getElementById('text-input').value;
    const voice = document.getElementById('voice-select').value;
    const speed = document.getElementById('speed-range').value;
    const pitch = document.getElementById('pitch-range').value;

    // Replace <your-ngrok-url> with your actual Ngrok URL
    const apiUrl = `https://4fdd4c761a11ec9bc35b8e911f8c2251.serveo.net/speak?text=${encodeURIComponent(text)}&voice=${voice}&speed=${speed}&pitch=${pitch}`;

    fetch(apiUrl)
        .then(response => response.blob())
        .then(blob => {
            const audioUrl = URL.createObjectURL(blob);
            const audio = document.getElementById('audio-output');
            audio.src = audioUrl;
            audio.play();
        })
        .catch(error => console.error('Error:', error));
});